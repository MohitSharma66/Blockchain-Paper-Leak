"""Configurable OCR-first PDF importer. Always returns an unverified draft."""
from __future__ import annotations
import io, re
import fitz
import pytesseract
from PIL import Image

QUESTION_PATTERNS = {
    "1)": r"(?m)^\s*(\d{1,3})\)\s+",
    "1.": r"(?m)^\s*(\d{1,3})\.\s+",
    "Q1": r"(?im)^\s*Q(?:uestion)?\s*(\d{1,3})\s*[:.)-]?\s+",
    "Question 1": r"(?im)^\s*Question\s+(\d{1,3})\s*[:.)-]?\s+",
}
OPTION_PATTERNS = {
    "(1)": r"(?m)^\s*\(([1-4])\)\s*",
    "1)": r"(?m)^\s*([1-4])\)\s*",
    "1.": r"(?m)^\s*([1-4])\.\s*",
    "(A)": r"(?im)^\s*\(([A-D])\)\s*",
    "A.": r"(?im)^\s*([A-D])\.\s*",
}

def _ocr_pdf(data: bytes) -> tuple[str, int]:
    try:
        doc = fitz.open(stream=data, filetype="pdf")
        if not doc.page_count:
            raise ValueError("The PDF has no pages.")
        pages = []
        for page in doc:
            # OCR image rendering avoids contaminated PDF text layers/watermarks.
            pix = page.get_pixmap(matrix=fitz.Matrix(1.5, 1.5), alpha=False)
            image = Image.open(io.BytesIO(pix.tobytes("png")))
            pages.append(pytesseract.image_to_string(image, config="--psm 6"))
        return "\n\n".join(pages), doc.page_count
    except ValueError:
        raise
    except Exception as exc:
        raise ValueError("Could not OCR this PDF. Check that it is valid and the OCR engine is installed.") from exc

def parse_exam_pdf(data: bytes, filename: str, question_format: str = "1)", option_format: str = "(1)", option_count: int = 4, question_boundary: str = "line") -> dict:
    if question_format not in QUESTION_PATTERNS:
        raise ValueError("Unsupported question identifier format.")
    if option_format not in OPTION_PATTERNS:
        raise ValueError("Unsupported option identifier format.")
    if question_boundary != "line":
        raise ValueError("Only line-start question boundaries are supported.")
    if option_count not in (2, 3, 4, 5, 6):
        raise ValueError("Options per question must be between 2 and 6.")
    text, page_count = _ocr_pdf(data)
    text = text.replace("\r", "\n").replace("\u00a0", " ")
    q_re = re.compile(QUESTION_PATTERNS[question_format])
    starts = list(q_re.finditer(text))
    if not starts:
        raise ValueError("No questions matched the selected identifier. Try a different question format.")
    opt_re = re.compile(OPTION_PATTERNS[option_format])
    questions, notes = [], []
    seen = set()
    for i, match in enumerate(starts):
        end = starts[i + 1].start() if i + 1 < len(starts) else len(text)
        block = text[match.end():end].strip()
        option_matches = list(opt_re.finditer(block))
        options = []
        if option_matches:
            stem = block[:option_matches[0].start()].strip()
            for j, om in enumerate(option_matches[:option_count]):
                stop = option_matches[j + 1].start() if j + 1 < len(option_matches) else len(block)
                value = block[om.end():stop].strip()
                options.append(re.sub(r"\s+", " ", value))
        else:
            stem = block
        stem = re.sub(r"\s+", " ", stem).strip()
        qid = int(match.group(1))
        issues = []
        if qid in seen: issues.append("duplicate question number")
        seen.add(qid)
        if len(options) != option_count: issues.append(f"detected {len(options)} of {option_count} options")
        options = (options + [""] * option_count)[:option_count]
        if not stem: issues.append("empty question text")
        questions.append({"id": qid, "question_text": stem, "options": options, "correct_index": None, "needs_review": bool(issues), "review_issues": issues})
        if issues: notes.append(f"Question {qid}: " + ", ".join(issues) + ".")
    if len(questions) > 500:
        raise ValueError("More than 500 question blocks detected; split the PDF and import smaller sections.")
    notes.insert(0, "OCR draft only. Verify every question, option, diagram and numbering. Correct answers are not inferred; upload an answer key separately.")
    return {"filename": filename, "pages": page_count, "identifier_settings": {"question_format": question_format, "question_boundary": question_boundary, "option_format": option_format, "option_count": option_count}, "paper": {"exam_name": re.sub(r"\.pdf$", "", filename, flags=re.I), "questions": questions}, "review_notes": notes}

def parse_answer_key(data: bytes, filename: str, questions: list[dict]) -> dict:
    """Read a text/CSV/PDF key and apply only explicit question-number -> answer mappings."""
    try:
        if filename.lower().endswith(".pdf"):
            text, _ = _ocr_pdf(data)
        else:
            text = data.decode("utf-8-sig", errors="replace")
    except Exception as exc:
        raise ValueError("Could not read the answer key.") from exc
    mapping = {"A": 0, "B": 1, "C": 2, "D": 3, "1": 0, "2": 1, "3": 2, "4": 3}
    found = {}
    # Supported rows: 1 A, 1) A, 1. A, Q1: A, or comma/tab separated pairs.
    for line in text.splitlines():
        m = re.match(r"^\s*(?:Q(?:uestion)?\s*)?(\d{1,3})\s*[).,:\-\t ]+\(?\s*([A-Da-d1-4])\s*\)?\s*$", line)
        if m:
            found[int(m.group(1))] = mapping[m.group(2).upper()]
    applied, missing = 0, []
    for q in questions:
        qid = int(q.get("id", q.get("question_number", 0)))
        if qid in found and len(q.get("options", [])) >= 4 and all(q["options"][:4]):
            q["correct_index"] = found[qid]
            applied += 1
        else:
            missing.append(qid)
    return {"applied": applied, "unmatched_question_ids": missing, "key_entries": len(found)}
