"""
pipeline.py

Shuffle -> render PDF -> encrypt -> store, once per variant, from one API call.

What gets persisted, and where:
    encrypted blob   -> blob store (Cloudflare R2, or local folder fallback)
    AES key          -> keys.db, encrypted under the master key
    answer key       -> keys.db, encrypted under the master key
    record           -> board.db (variant, fingerprint, blob hash, object key)

No plaintext PDF, variant JSON or raw key is ever written to disk.
"""

import io
import os
import hashlib
import secrets
import random

from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.pdfgen import canvas
from reportlab.lib.utils import simpleSplit

import db
import keystore
from storage import get_blob_store

OPTION_LABELS = ["A", "B", "C", "D"]
MAX_VARIANTS = 500


# ---------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------

def validate_paper(paper) -> None:
    """Raise ValueError with a clear message if the uploaded JSON is unusable."""
    if not isinstance(paper, dict):
        raise ValueError("Paper JSON must be an object with 'exam_name' and 'questions'.")
    if not isinstance(paper.get("exam_name"), str) or not paper["exam_name"].strip():
        raise ValueError("Paper JSON needs a non-empty 'exam_name' string.")

    questions = paper.get("questions")
    if not isinstance(questions, list) or not questions:
        raise ValueError("Paper JSON needs a non-empty 'questions' list.")

    seen_ids = set()
    for i, q in enumerate(questions, start=1):
        where = f"Question #{i}"
        if not isinstance(q, dict):
            raise ValueError(f"{where} must be an object.")
        for field in ("id", "question_text", "options", "correct_index"):
            if field not in q:
                raise ValueError(f"{where} is missing '{field}'.")
        if q["id"] in seen_ids:
            raise ValueError(f"{where} reuses id {q['id']}.")
        seen_ids.add(q["id"])
        if not isinstance(q["question_text"], str) or not q["question_text"].strip():
            raise ValueError(f"{where} has empty question_text.")
        opts = q["options"]
        if not isinstance(opts, list) or len(opts) != 4:
            raise ValueError(f"{where} must have exactly 4 options.")
        if not all(isinstance(o, str) and o.strip() for o in opts):
            raise ValueError(f"{where} has an empty or non-text option.")
        if len(set(opts)) != 4:
            raise ValueError(f"{where} has duplicate options (shuffling would be ambiguous).")
        ci = q["correct_index"]
        if not isinstance(ci, int) or isinstance(ci, bool) or not 0 <= ci <= 3:
            raise ValueError(f"{where} has correct_index {ci!r}; it must be 0, 1, 2 or 3.")


# ---------------------------------------------------------------------
# Shuffle + fingerprint
# ---------------------------------------------------------------------

def _shuffle_question(question: dict, rng: random.Random) -> dict:
    options = question["options"]
    correct_text = options[question["correct_index"]]
    shuffled = options.copy()
    rng.shuffle(shuffled)
    return {**question, "options": shuffled, "correct_index": shuffled.index(correct_text)}


def _fingerprint(variant: dict) -> str:
    # Same scheme as generate_variants.py: hash of the option order across the paper.
    signature = "".join("".join(q["options"]) for q in variant["questions"])
    return hashlib.sha256(signature.encode("utf-8")).hexdigest()


def _build_variant(paper: dict, variant_id: str, seed: int) -> dict:
    rng = random.Random(seed)
    return {
        "exam_name": paper["exam_name"],
        "variant_id": variant_id,
        "questions": [_shuffle_question(q, rng) for q in paper["questions"]],
    }


# ---------------------------------------------------------------------
# PDF render + encrypt
# ---------------------------------------------------------------------

def _render_pdf_bytes(variant: dict) -> bytes:
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=A4)
    width, height = A4
    margin = 20 * mm
    y = height - margin

    c.setFont("Helvetica-Bold", 14)
    c.drawString(margin, y, variant["exam_name"])
    y -= 10 * mm
    c.setFont("Helvetica", 9)
    c.drawString(margin, y, f"Variant reference: {variant['variant_id']}")
    y -= 12 * mm

    for q in variant["questions"]:
        c.setFont("Helvetica-Bold", 11)
        for line in simpleSplit(f"Q{q['id']}. {q['question_text']}", "Helvetica-Bold", 11, width - 2 * margin):
            if y < margin:
                c.showPage()
                y = height - margin
                c.setFont("Helvetica-Bold", 11)
            c.drawString(margin, y, line)
            y -= 6 * mm

        c.setFont("Helvetica", 10)
        for label, text in zip(OPTION_LABELS, q["options"]):
            for line in simpleSplit(f"({label}) {text}", "Helvetica", 10, width - 2 * margin - 8 * mm):
                if y < margin:
                    c.showPage()
                    y = height - margin
                    c.setFont("Helvetica", 10)
                c.drawString(margin + 8 * mm, y, line)
                y -= 5.5 * mm
        y -= 4 * mm

    c.save()
    return buf.getvalue()


def _encrypt(pdf_bytes: bytes, key: bytes) -> bytes:
    nonce = os.urandom(12)
    return nonce + AESGCM(key).encrypt(nonce, pdf_bytes, None)


# ---------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------

def _next_index() -> int:
    """Continue numbering after the highest existing center_NNN in the database."""
    highest = 0
    for center_id in db.list_all_centers():
        try:
            highest = max(highest, int(center_id.split("_")[-1]))
        except ValueError:
            pass
    return highest + 1


def generate_all(paper: dict, num_variants: int) -> list[dict]:
    """
    One variant per center (variant_N <-> center_NNN). Returns one summary
    dict per center. If anything fails part-way, the centers of this batch that
    were already created are rolled back, so no record ever points at a missing
    blob or key.
    """
    validate_paper(paper)
    if not isinstance(num_variants, int) or not 1 <= num_variants <= MAX_VARIANTS:
        raise ValueError(f"Number of variants must be between 1 and {MAX_VARIANTS}.")

    # 4 options -> 24 orderings per question; the paper can only yield 24^Q distinct variants.
    if len(paper["questions"]) <= 2 and num_variants > 24 ** len(paper["questions"]):
        raise ValueError(
            f"A paper with {len(paper['questions'])} question(s) can only produce "
            f"{24 ** len(paper['questions'])} distinct variants."
        )

    # Fail fast on configuration problems, before creating anything.
    keystore.require_master_key()
    store = get_blob_store()
    store.check()

    start = _next_index()
    used_fingerprints = set()
    results = []
    created = []  # (center_id, variant_id, object_key) for rollback

    try:
        for offset in range(num_variants):
            n = start + offset
            variant_id = f"variant_{n}"
            center_id = f"center_{n:03d}"

            # Random (unpredictable) seed; retry until this ordering is unique in the batch.
            for _ in range(200):
                variant = _build_variant(paper, variant_id, secrets.randbits(64))
                fingerprint = _fingerprint(variant)
                if fingerprint not in used_fingerprints:
                    break
            else:
                raise ValueError("Could not generate enough distinct variants from this paper.")
            used_fingerprints.add(fingerprint)

            pdf_bytes = _render_pdf_bytes(variant)
            answers = [{"id": q["id"], "correct_index": q["correct_index"]} for q in variant["questions"]]

            key = AESGCM.generate_key(bit_length=256)
            blob = _encrypt(pdf_bytes, key)
            blob_hash = hashlib.sha256(blob).hexdigest()
            # Random suffix: a re-run never silently overwrites an older object in the bucket.
            object_key = f"blobs/{center_id}-{secrets.token_hex(4)}.enc"

            # Record goes in last, so it only exists once everything it points at does.
            store.put(object_key, blob)
            created.append((center_id, variant_id, object_key))
            keystore.store_key(center_id, key)
            keystore.store_answers(variant_id, answers)
            db.upsert_center_record(
                center_id=center_id,
                variant_id=variant_id,
                fingerprint=fingerprint,
                blob_hash=blob_hash,
                blob_object_key=object_key,
            )

            results.append({
                "center_id": center_id,
                "variant_id": variant_id,
                "blob_hash": blob_hash,
                "fingerprint": fingerprint,
            })
    except Exception:
        for center_id, variant_id, object_key in created:
            try:
                db.delete_center(center_id)
                keystore.purge(center_id, variant_id)
                store.delete(object_key)
            except Exception:
                pass  # best effort; an orphaned object is harmless (it's ciphertext)
        raise

    return results
